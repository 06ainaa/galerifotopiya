<?php
session_start();
include 'koneksi.php'; // Sesuaikan dengan path file koneksi.php

// Pastikan request adalah HTTP POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Pastikan user telah login
    if (!isset($_SESSION['userid'])) {
        // Redirect atau tampilkan pesan error sesuai kebutuhan
        echo "Anda belum login.";
        exit;
    }
    
    // Ambil komentarid dari form
    $komentarid = $_POST['komentarid'];

    // Query untuk menghapus komentar berdasarkan komentarid
    $query = "DELETE FROM komentarfoto WHERE komentarid = ?";
    
    // Persiapkan statement
    $stmt = $koneksi->prepare($query);

    // Bind parameter ke statement
    $stmt->bind_param("i", $komentarid);

    // Eksekusi statement
    if ($stmt->execute()) {
        // Komentar berhasil dihapus
        echo "Komentar berhasil dihapus.";
    } else {
        // Gagal menghapus komentar
        echo "Gagal menghapus komentar.";
    }
} else {
    // Request bukan POST, mungkin bisa di-handle dengan redirect atau pesan error
    echo "Permintaan tidak valid.";
}
?>
