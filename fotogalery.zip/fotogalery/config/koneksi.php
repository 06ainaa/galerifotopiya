<?php
$hostname='localhost';
$userdb='root';
$passdb='';
$namedb='fotogalery';

$koneksi = mysqli_connect($hostname, $userdb, $passdb, $namedb);

if ($koneksi) {
    echo "";
}else{
    echo "Tidak Terhubung";

}
?>