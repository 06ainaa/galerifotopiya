<?php 
session_start();
include 'koneksi.php';

$fotoid = $_POST['fotoid'];
$userid =$_SESSION['userid'];
$isikomentar = $_POST['isikomentar'];
$tanggalkomentar = date('Y-m-d');

$query = mysqli_query($koneksi, "INSERT INTO komentarfoto VALUES('','$fotoid','$userid','$isikomentar','$tanggalkomentar')");

echo "<script>
    
    location.href='../admin/index.php';

    
    </script>";
    
    if (isset($_POST['hapus'])){
        $komentarid = $_POST['komentarid'];
    
        $sql = mysqli_query($koneksi, "DELETE FROM komentarfoto WHERE komentarid='$komentarid'");
    
        echo "<script>
        alert('Komentar Berhasil Dihapus!');
        location.href='../admin/home.php';    
        </script>";
    }
?>
